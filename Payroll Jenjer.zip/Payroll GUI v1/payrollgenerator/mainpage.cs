﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace payrollgenerator
{
    public partial class mainpage : MetroFramework.Forms.MetroForm
    {
        Boolean hidden;
        int panelwidth;
        string instruction = "";

        /// Embedded Font ///
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern IntPtr AddFontMemResourceEx(IntPtr pbFont, uint cbFont,
            IntPtr pdv, [System.Runtime.InteropServices.In] ref uint pcFonts);

        private PrivateFontCollection fonts = new PrivateFontCollection();

        Font myFont;
        Font boxFont;
        Font labelFont;
        
        public mainpage()
        {
            InitializeComponent();

            byte[] fontData = Properties.Resources.prototype_font;
            IntPtr fontPtr = System.Runtime.InteropServices.Marshal.AllocCoTaskMem(fontData.Length);
            System.Runtime.InteropServices.Marshal.Copy(fontData, 0, fontPtr, fontData.Length);
            uint dummy = 0;
            fonts.AddMemoryFont(fontPtr, Properties.Resources.prototype_font.Length);
            AddFontMemResourceEx(fontPtr, (uint)Properties.Resources.prototype_font.Length, IntPtr.Zero, ref dummy);
            System.Runtime.InteropServices.Marshal.FreeCoTaskMem(fontPtr);

            myFont = new Font(fonts.Families[0], 12.0F);
            boxFont = new Font(fonts.Families[0], 13.0F);
            labelFont = new Font(fonts.Families[0], 10.0F);

            panelwidth = menupanel.Width;
            hidden = false;
        }

        /// Embedded Font ///

        public static float basicpay = 0;
        public static float overtimepay = 0;
        public static float undertimepay = 0;
        public static float absencespay = 0;
        public static float tardinesspay = 0;
        public static float totalearnings = 0;
        public static float totaldeductions = 0;
        public static float totalcont = 0;
        public static float takehome = 0;

        public static String empnum = "";
        public static String empname = "";
        public static String error = "Fill all Fields!";

        private void database_Load(object sender, EventArgs e)
        {

            // Employee Information
            namelabel.Font = myFont;
            idlabel.Font = myFont;

            // Earnings
            ratelabel.Font = myFont;
            basiclabel.Font = myFont;
            overtimelabel.Font = myFont;
            undertimelabel.Font = myFont;
            absentlabel.Font = myFont;
            latelabel.Font = myFont;

            // Deductions
            ssslabel.Font = myFont;
            phillabel.Font = myFont;
            canteenlabel.Font = myFont;
            cashlabel.Font = myFont;
            loanlabel.Font = myFont;
            otherlabel.Font = myFont;

            // Employee's Contribution
            contssslabel.Font = myFont;
            contphillabel.Font = myFont;

            // Groupboxes
            earningbox.Font = boxFont;
            deductbox.Font = boxFont;
            employeebox.Font = boxFont;    
            contbox.Font = boxFont;         

            // Menu Buttons
            newButton.Font = boxFont;       
            recordButton.Font = boxFont;
            printedButton.Font = boxFont;
            logoutButton.Font = boxFont;
            employeeButton.Font = boxFont;

            // Textboxes

            namebox.Font = myFont;
            idbox.Font = myFont;
            ratebox.Font = myFont;
            basicbox.Font = myFont;
            overtimebox.Font = myFont;
            undertimebox.Font = myFont;
            absentbox.Font = myFont;
            latebox.Font = myFont;
            sssbox.Font = myFont;
            philbox.Font = myFont;
            canteenbox.Font = myFont;
            cashbox.Font = myFont;
            loanbox.Font = myFont;
            othersbox.Font = myFont;
            contsssbox.Font = myFont;
            contphilbox.Font = myFont;

            // LABELS

            instructionlabel.Font = boxFont;
            themeslabel.Font = myFont;
            darkshadelabel.Font = myFont;
            monokailabel.Font = myFont;
            generatebutton.Font = myFont;
            payrolldatelabel.Font = myFont;
            companylabel.Font = myFont;
            frequencylabel.Font = myFont;
            taxlabel.Font = myFont;
            datelabel.Font = myFont;
               

            datelabel.Text = DateTime.Now.ToString("dddd, MMM dd yyyy");
        }

        float deductsss;
        float deductphilhealth;
        float deductcanteen;
        float deductcashadv;
        float deductloans;
        float deductothers;
        float contrisss;
        float contriphil;

        private void generatepayslip_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(ratebox.Text)     ||
                string.IsNullOrWhiteSpace(basicbox.Text)    ||
                string.IsNullOrWhiteSpace(overtimebox.Text) ||
                string.IsNullOrWhiteSpace(undertimebox.Text)||
                string.IsNullOrWhiteSpace(absentbox.Text)   ||
                string.IsNullOrWhiteSpace(latebox.Text)     ||
                string.IsNullOrWhiteSpace(namebox.Text)     ||
                string.IsNullOrWhiteSpace(idbox.Text))
            {
                var emptyfield = new emptyfield();
                emptyfield.ShowDialog();
            }
            else
            {
                // SSS
                if (string.IsNullOrWhiteSpace(sssbox.Text))
                {
                    deductsss = 0;
                } else
                {
                    deductsss = Convert.ToSingle(sssbox.Text);
                }
                // Philhealth
                if (string.IsNullOrWhiteSpace(philbox.Text))
                {
                    deductphilhealth = 0;
                }
                else
                {
                    deductphilhealth = Convert.ToSingle(philbox.Text);
                }
                // Canteen
                if (string.IsNullOrWhiteSpace(canteenbox.Text))
                {
                    deductcanteen = 0;
                }
                else
                {
                    deductcanteen = Convert.ToSingle(canteenbox.Text);
                }
                // Cash Advanced
                if (string.IsNullOrWhiteSpace(cashbox.Text))
                {
                    deductcashadv = 0;
                }
                else
                {
                    deductcashadv = Convert.ToSingle(cashbox.Text);
                }
                // Loan
                if (string.IsNullOrWhiteSpace(loanbox.Text))
                {
                    deductloans = 0;
                }
                else
                {
                    deductloans = Convert.ToSingle(loanbox.Text);
                }
                // Others
                if (string.IsNullOrWhiteSpace(othersbox.Text))
                {
                    deductothers = 0;
                }
                else
                {
                    deductothers = Convert.ToSingle(othersbox.Text);
                }
                // SSS Contribution
                if (string.IsNullOrWhiteSpace(contsssbox.Text))
                {
                    contrisss = 0;
                }
                else
                {
                    contrisss = Convert.ToSingle(contsssbox.Text);
                }
                // Philhealth Contribution
                if (string.IsNullOrWhiteSpace(contphilbox.Text))
                {
                    contriphil = 0;
                }
                else
                {
                    contriphil = Convert.ToSingle(contphilbox.Text);
                }

                payslip payslip = new payslip();

                // Assigning Textbox Values to Variable
                float rateperhour = Convert.ToSingle(ratebox.Text);
                int basic = Convert.ToInt32(basicbox.Text);
                int overtime = Convert.ToInt32(overtimebox.Text);
                int undertime = Convert.ToInt32(undertimebox.Text);
                int absences = Convert.ToInt32(absentbox.Text);
                int latemins = Convert.ToInt32(latebox.Text);

                basicpay = basic * rateperhour;
                basicpay.ToString();            // Basic Total
                overtimepay = overtime * rateperhour;
                overtimepay.ToString();         // Overtime Total
                undertimepay = undertime * rateperhour;
                undertimepay.ToString();        // Undertime Total
                absencespay = (absences * 8) * rateperhour;
                absencespay.ToString();         // Absences Total
                tardinesspay = (rateperhour / 60) * latemins;
                tardinesspay.ToString();        // Tardines Total
                totalearnings = basicpay + overtimepay;
                totalearnings.ToString();       // Total Earnings
                totaldeductions = deductsss + deductphilhealth + deductcanteen + deductcashadv + deductloans + deductothers;
                totaldeductions.ToString();     // Total Deductions
                totalcont = contrisss + contriphil;
                totalcont.ToString();           // Total Contributions
                takehome = (totalearnings - totaldeductions) - totalcont;

                // Passing Values to Payslip Form

                payslip.takehomepay = takehome;
                payslip.totalcontri = totalcont;
                payslip.totaldeduct = totaldeductions;
                payslip.contsss = contrisss;
                payslip.contphilhealth = contriphil;
                payslip.sss = deductsss;
                payslip.philhealth = deductphilhealth;
                payslip.canteen = deductcanteen;
                payslip.cashadv = deductcashadv;
                payslip.loans = deductloans;
                payslip.others = deductothers;
                payslip.totalearn = totalearnings;
                payslip.hourswork = basic;
                payslip.ratexbasic = basicpay;
                payslip.overtimehours = overtime;
                payslip.overxrate = overtimepay;
                payslip.undertimehours = undertime;
                payslip.underxrate = undertimepay;
                payslip.absentdays = absences;
                payslip.absentxrate = absencespay;
                payslip.latemins = latemins;
                payslip.latexrate = tardinesspay;

                empnum = idbox.Text;
                empname = namebox.Text;
                empname = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(empname.ToLower());

                this.Hide();
                payslip.ShowDialog();


            }
  
        }

        private void printedButton_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", @"D:");
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            var logout = new logout();
            logout.ShowDialog();
        }

        Point lastPoint;

        private void ratebox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && ratebox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void basicbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void othersbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && othersbox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void loanbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && loanbox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void cashbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && cashbox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void canteenbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && canteenbox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void philbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && philbox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void sssbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && sssbox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void contsssbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && contsssbox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void contphilbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && contphilbox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void namebox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (ch == 46 && namebox.Text.IndexOf('.') != -1)
            {
                e.Handled = true;
                return;
            }
            if (!Char.IsLetter(ch) && ch != 8 && ch != 46 && ch != 32 && ch != 8 )
            {
                e.Handled = true;
            }
        }

        

        // DRAG BORDERLESS FORM

        private void dragform_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void dragform_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        //INSTRUCTION TEXT FUNCTION

        public void InstructionText(String text)
        {
            instruction = text;
            instructionlabel.Text = instruction;
        }

        // TEXTBOX INSTRUCTIONS

        private void namebox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Enter Full Name");
        }

        private void idbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Enter Employee ID");
        }

        private void contsssbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("SSS Contribution  ( optional )");
        }

        private void contphilbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Philhealth Contribution  ( optional )");
        }

        private void ratebox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Rate Per Hour");
        }

        private void basicbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Total Hours Worked");
        }

        private void overtimebox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Total Overtime Hours");
        }

        private void undertimebox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Total Undertime Hours");
        }

        private void absentbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Number of Absents");
        }

        private void latebox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Total Late Time");
        }

        private void sssbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("SSS Deduction  ( optional )");
        }

        private void philbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Philhealth Deduction  ( optional )");
        }

        private void canteenbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Canteen Debt  ( optional )");
        }

        private void cashbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Total Cash Advanced  ( optional )");
        }

        private void loanbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Total Loans  ( optional )");
        }

        private void othersbox_MouseMove(object sender, MouseEventArgs e)
        {
            InstructionText("Other Expenses  ( optional )");
        }

        // MINIMIZE BUTTON

        private void minimizebutton_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        // SETTINGS BUTTON

        private void settingsbutton_Click(object sender, EventArgs e)
        {
            if (settingsPanel.Visible)
            {
                settingsPanel.Hide();
            } else if (!settingsPanel.Visible)
            {
                settingsPanel.Show();
            }
        }

        // DARK SHADE THEME CHECKED

        private void darktheme_CheckedChanged(object sender, EventArgs e)
        {
            if (darktheme.Checked)
            {
                monokaitheme.Checked = false;

                settingsPanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#2D2D2D"); 
                controlpanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#232323");
                menupanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#1B1B1B");
                basepanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#0F0F0F");
                instructionpanel.BaseColor = System.Drawing.ColorTranslator.FromHtml("#313131");

                Control[] groupboxes = { earningbox, employeebox, deductbox, contbox };

                for (int i = 0; i < 4; i++)
                {
                    foreach (Control c in groupboxes[i].Controls)
                    {
                        ((Guna.UI.WinForms.GunaGroupBox)groupboxes[i]).LineColor = System.Drawing.ColorTranslator.FromHtml("#373737");
                        ((Guna.UI.WinForms.GunaGroupBox)groupboxes[i]).BaseColor = System.Drawing.ColorTranslator.FromHtml("#191919");

                        if (c is Guna.UI.WinForms.GunaTextBox)
                        {
                            ((Guna.UI.WinForms.GunaTextBox)c).ForeColor = System.Drawing.ColorTranslator.FromHtml("#0F0F0F");
                            ((Guna.UI.WinForms.GunaTextBox)c).BaseColor = System.Drawing.ColorTranslator.FromHtml("#EAEAEA");
                            ((Guna.UI.WinForms.GunaTextBox)c).FocusedForeColor = System.Drawing.ColorTranslator.FromHtml("#EAEAEA");
                            ((Guna.UI.WinForms.GunaTextBox)c).FocusedBorderColor = System.Drawing.ColorTranslator.FromHtml("#EAEAEA");
                            ((Guna.UI.WinForms.GunaTextBox)c).FocusedBaseColor = System.Drawing.ColorTranslator.FromHtml("#0F0F0F");
                        }
                    }
                }

                foreach (Control earningTB in groupboxes[0].Controls)
                {
                    if (earningTB is Guna.UI.WinForms.GunaTextBox)
                    {
                        earningTB.Enter += new System.EventHandler(dark_earningboxcolor_MouseEnter);
                    }
                }

                foreach (Control employTB in groupboxes[1].Controls)
                {
                    if (employTB is Guna.UI.WinForms.GunaTextBox)
                    {
                        employTB.Enter += new System.EventHandler(dark_employboxcolor_MouseEnter);
                    }
                }


                foreach (Control deductTB in groupboxes[2].Controls)
                {
                    if (deductTB is Guna.UI.WinForms.GunaTextBox)
                    {
                        deductTB.Enter += new System.EventHandler(dark_deductboxcolor_MouseEnter);
                    }
                }


                foreach (Control contriTB in groupboxes[3].Controls)
                {
                    if (contriTB is Guna.UI.WinForms.GunaTextBox)
                    {
                        contriTB.Enter += new System.EventHandler(dark_contboxcolor_MouseEnter);
                    }
                }
            }


            // DARK SHADE THEME UNCHECKED

            else if (!darktheme.Checked)
            {
                settingsPanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#003E3E");
                controlpanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#003232");
                menupanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#003737");
                basepanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#002323");
                instructionpanel.BaseColor = System.Drawing.ColorTranslator.FromHtml("#008080");

                Control[] groupboxes = { earningbox, employeebox, deductbox, contbox };

                for (int i = 0; i < 4; i++)
                {
                    foreach (Control c in groupboxes[i].Controls)
                    {
                        ((Guna.UI.WinForms.GunaGroupBox)groupboxes[i]).LineColor = System.Drawing.ColorTranslator.FromHtml("#005A5A");
                        ((Guna.UI.WinForms.GunaGroupBox)groupboxes[i]).BaseColor = System.Drawing.ColorTranslator.FromHtml("#003C3C");

                        if (c is Guna.UI.WinForms.GunaTextBox)
                        {
                            ((Guna.UI.WinForms.GunaTextBox)c).ForeColor = System.Drawing.ColorTranslator.FromHtml("#002323");
                            ((Guna.UI.WinForms.GunaTextBox)c).BaseColor = System.Drawing.ColorTranslator.FromHtml("#CEFFFF");
                            ((Guna.UI.WinForms.GunaTextBox)c).FocusedForeColor = System.Drawing.ColorTranslator.FromHtml("#CEFFFF");
                            ((Guna.UI.WinForms.GunaTextBox)c).FocusedBorderColor = System.Drawing.ColorTranslator.FromHtml("#CEFFFF");
                            ((Guna.UI.WinForms.GunaTextBox)c).FocusedBaseColor = System.Drawing.ColorTranslator.FromHtml("#002323");
                        }
                    }
                }

                foreach (Control earningTB in groupboxes[0].Controls)
                {
                    if (earningTB is Guna.UI.WinForms.GunaTextBox)
                    {
                        earningTB.Enter += new System.EventHandler(default_earningboxcolor_MouseEnter);
                    }
                }

                foreach (Control employTB in groupboxes[1].Controls)
                {
                    if (employTB is Guna.UI.WinForms.GunaTextBox)
                    {
                        employTB.Enter += new System.EventHandler(default_employboxcolor_MouseEnter);
                    }
                }


                foreach (Control deductTB in groupboxes[2].Controls)
                {
                    if (deductTB is Guna.UI.WinForms.GunaTextBox)
                    {
                        deductTB.Enter += new System.EventHandler(default_deductboxcolor_MouseEnter);
                    }
                }


                foreach (Control contriTB in groupboxes[3].Controls)
                {
                    if (contriTB is Guna.UI.WinForms.GunaTextBox)
                    {
                        contriTB.Enter += new System.EventHandler(default_contboxcolor_MouseEnter);
                    }
                }
            }
        }

        // MONOKAI THEME

        private void monokai_CheckedChanged(object sender, EventArgs e)
        {
            if (monokaitheme.Checked)
            {
                darktheme.Checked = false;
                basepanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFF");
            } else if (!darktheme.Checked)
            {
                basepanel.BackColor = System.Drawing.ColorTranslator.FromHtml("#002323");
            }
        }

        // COLOR VARIABLES

        //Default Theme

        Color default_active_box = System.Drawing.ColorTranslator.FromHtml("#007777");
        Color default_inactive_box = System.Drawing.ColorTranslator.FromHtml("#005A5A");

        //Dark Theme

        Color dark_active_box = System.Drawing.ColorTranslator.FromHtml("#4F4F4F");
        Color dark_inactive_box = System.Drawing.ColorTranslator.FromHtml("#373737");

        //MOUSE ENTER COLORS FUNCTION

        public void MouseEnterColors(Color a, Color b, Color c, Color d)
        {
            earningbox.LineColor = a;
            deductbox.LineColor = b;
            employeebox.LineColor = c;
            contbox.LineColor = d;
        }

        // DEFAULT THEME

        private void default_earningboxcolor_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterColors(default_active_box, default_inactive_box, default_inactive_box, default_inactive_box);
        }

        private void default_deductboxcolor_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterColors(default_inactive_box, default_active_box, default_inactive_box, default_inactive_box);
        }

        private void default_employboxcolor_MouseEnter(object sender, EventArgs e)
        {

            MouseEnterColors(default_inactive_box, default_inactive_box, default_active_box, default_inactive_box);
        }

        private void default_contboxcolor_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterColors(default_inactive_box, default_inactive_box, default_inactive_box, default_active_box);
        }

        // DARK THEME

        private void dark_earningboxcolor_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterColors(dark_active_box, dark_inactive_box, dark_inactive_box, dark_inactive_box);
        }

        private void dark_deductboxcolor_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterColors(dark_inactive_box, dark_active_box, dark_inactive_box, dark_inactive_box);
        }

        private void dark_employboxcolor_MouseEnter(object sender, EventArgs e)
        {

            MouseEnterColors(dark_inactive_box, dark_inactive_box, dark_active_box, dark_inactive_box);
        }

        private void dark_contboxcolor_MouseEnter(object sender, EventArgs e)
        {
            MouseEnterColors(dark_inactive_box, dark_inactive_box, dark_inactive_box, dark_active_box);
        }
    }
}
