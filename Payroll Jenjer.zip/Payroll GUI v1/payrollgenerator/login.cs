﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Text.RegularExpressions;


namespace payrollgenerator
{


    public partial class login : MetroFramework.Forms.MetroForm
    {
        public static string username = "1";
        public static string password = "1";
        public static string errors = "";

        public login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void metroTextBox1_ButtonClick(object sender, EventArgs e)
        {

        }

        private void metroProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            metroProgressBar1.Value += 2;
            if (metroProgressBar1.Value >= 100)
            {
                timer1.Enabled = false;
                bool confirmOpen = false;
                foreach (Form theform in Application.OpenForms)
                {
                    if (theform.Name == "confirmation")
                    {
                        confirmOpen = true;
                        theform.BringToFront();
                        break;
                    }
                }
                if (confirmOpen == false)
                {
                    success confirmation = new success();
                    confirmation.ShowDialog();
                }
                metroProgressBar1.Value = 0;
                Application.OpenForms["login"].Hide();
            }
        }

        private void metroTextBox1_KeyPress(object sender, KeyPressEventArgs textonly)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string passinput = metroTextBox1.Text;
            string userinput = metroTextBox2.Text;

            if (String.IsNullOrWhiteSpace(userinput) || String.IsNullOrWhiteSpace(passinput))
            {
                bool errorOpen = false;
                errors = "Field is Empty!";
                foreach (Form theform in Application.OpenForms)
                {
                    if (theform.Name == "empty_error")
                    {
                        errorOpen = true;
                        theform.BringToFront();
                        break;
                    }
                }
                if (errorOpen == false)
                {
                    error empty_error = new error();
                    empty_error.ShowDialog();
                }
            }
            else if (userinput != username || passinput != password)
            {
                bool shortOpen = false;
                errors = "Invalid Entry!";
                foreach (Form theform in Application.OpenForms)
                {
                    if (theform.Name == "short_error")
                    {
                        shortOpen = true;
                        theform.BringToFront();
                        break;
                    }
                }
                if (shortOpen == false)
                {
                    error empty_error = new error();
                    empty_error.ShowDialog();
                }

            }
            else if (userinput == username && passinput == password)
            {
                timer1.Enabled = true;
            }
        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
