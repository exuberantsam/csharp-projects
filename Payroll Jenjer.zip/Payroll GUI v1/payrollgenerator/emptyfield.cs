﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace payrollgenerator
{
    public partial class emptyfield : MetroFramework.Forms.MetroForm
    {
        public emptyfield()
        {
            InitializeComponent();
        }

        private void emptyfield_Load(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Hand.Play();
            label1.Text = mainpage.error;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
