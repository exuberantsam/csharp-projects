﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace payrollgenerator
{
    public partial class error : MetroFramework.Forms.MetroForm
    {
        public error()
        {
            InitializeComponent();
        }

        private void error_Load(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Hand.Play();
            label1.Text = login.errors;
            this.TopMost = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
