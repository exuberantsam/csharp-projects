﻿namespace payrollgenerator
{
    partial class mainpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainpage));
            this.frequencylabel = new System.Windows.Forms.Label();
            this.payrolldatelabel = new System.Windows.Forms.Label();
            this.companylabel = new System.Windows.Forms.Label();
            this.datelabel = new System.Windows.Forms.Label();
            this.taxlabel = new System.Windows.Forms.Label();
            this.basepanel = new MetroFramework.Controls.MetroPanel();
            this.generatebutton = new Guna.UI.WinForms.GunaAdvenceButton();
            this.settingsPanel = new Guna.UI.WinForms.GunaPanel();
            this.monokailabel = new System.Windows.Forms.Label();
            this.darkshadelabel = new System.Windows.Forms.Label();
            this.themeslabel = new System.Windows.Forms.Label();
            this.monokaitheme = new Guna.UI.WinForms.GunaWinSwitch();
            this.darktheme = new Guna.UI.WinForms.GunaWinSwitch();
            this.instructionpanel = new Guna.UI.WinForms.GunaElipsePanel();
            this.instructionlabel = new System.Windows.Forms.Label();
            this.contbox = new Guna.UI.WinForms.GunaGroupBox();
            this.contphillabel = new System.Windows.Forms.Label();
            this.contsssbox = new Guna.UI.WinForms.GunaTextBox();
            this.contphilbox = new Guna.UI.WinForms.GunaTextBox();
            this.contssslabel = new System.Windows.Forms.Label();
            this.employeebox = new Guna.UI.WinForms.GunaGroupBox();
            this.idlabel = new System.Windows.Forms.Label();
            this.namebox = new Guna.UI.WinForms.GunaTextBox();
            this.idbox = new Guna.UI.WinForms.GunaTextBox();
            this.namelabel = new System.Windows.Forms.Label();
            this.deductbox = new Guna.UI.WinForms.GunaGroupBox();
            this.otherlabel = new System.Windows.Forms.Label();
            this.loanbox = new Guna.UI.WinForms.GunaTextBox();
            this.phillabel = new System.Windows.Forms.Label();
            this.sssbox = new Guna.UI.WinForms.GunaTextBox();
            this.canteenlabel = new System.Windows.Forms.Label();
            this.othersbox = new Guna.UI.WinForms.GunaTextBox();
            this.loanlabel = new System.Windows.Forms.Label();
            this.philbox = new Guna.UI.WinForms.GunaTextBox();
            this.cashlabel = new System.Windows.Forms.Label();
            this.canteenbox = new Guna.UI.WinForms.GunaTextBox();
            this.ssslabel = new System.Windows.Forms.Label();
            this.cashbox = new Guna.UI.WinForms.GunaTextBox();
            this.earningbox = new Guna.UI.WinForms.GunaGroupBox();
            this.latelabel = new System.Windows.Forms.Label();
            this.absentbox = new Guna.UI.WinForms.GunaTextBox();
            this.basiclabel = new System.Windows.Forms.Label();
            this.ratebox = new Guna.UI.WinForms.GunaTextBox();
            this.overtimelabel = new System.Windows.Forms.Label();
            this.latebox = new Guna.UI.WinForms.GunaTextBox();
            this.absentlabel = new System.Windows.Forms.Label();
            this.basicbox = new Guna.UI.WinForms.GunaTextBox();
            this.undertimelabel = new System.Windows.Forms.Label();
            this.overtimebox = new Guna.UI.WinForms.GunaTextBox();
            this.ratelabel = new System.Windows.Forms.Label();
            this.undertimebox = new Guna.UI.WinForms.GunaTextBox();
            this.menupanel = new Guna.UI.WinForms.GunaPanel();
            this.employeeButton = new Guna.UI.WinForms.GunaAdvenceButton();
            this.newButton = new Guna.UI.WinForms.GunaAdvenceButton();
            this.printedButton = new Guna.UI.WinForms.GunaAdvenceButton();
            this.recordButton = new Guna.UI.WinForms.GunaAdvenceButton();
            this.logoutButton = new Guna.UI.WinForms.GunaAdvenceButton();
            this.controlpanel = new Guna.UI.WinForms.GunaPanel();
            this.minimizebutton = new Guna.UI.WinForms.GunaTileButton();
            this.settingsbutton = new Guna.UI.WinForms.GunaTileButton();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.basepanel.SuspendLayout();
            this.settingsPanel.SuspendLayout();
            this.instructionpanel.SuspendLayout();
            this.contbox.SuspendLayout();
            this.employeebox.SuspendLayout();
            this.deductbox.SuspendLayout();
            this.earningbox.SuspendLayout();
            this.menupanel.SuspendLayout();
            this.controlpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // frequencylabel
            // 
            this.frequencylabel.AutoSize = true;
            this.frequencylabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.frequencylabel.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.frequencylabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.frequencylabel.Location = new System.Drawing.Point(12, 8);
            this.frequencylabel.Name = "frequencylabel";
            this.frequencylabel.Size = new System.Drawing.Size(134, 17);
            this.frequencylabel.TabIndex = 0;
            this.frequencylabel.Text = "Frequency  :  Weekly";
            this.frequencylabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // payrolldatelabel
            // 
            this.payrolldatelabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.payrolldatelabel.AutoSize = true;
            this.payrolldatelabel.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payrolldatelabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.payrolldatelabel.Location = new System.Drawing.Point(840, 8);
            this.payrolldatelabel.Name = "payrolldatelabel";
            this.payrolldatelabel.Size = new System.Drawing.Size(47, 17);
            this.payrolldatelabel.TabIndex = 1000;
            this.payrolldatelabel.Text = "Date  :";
            this.payrolldatelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // companylabel
            // 
            this.companylabel.AutoSize = true;
            this.companylabel.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companylabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.companylabel.Location = new System.Drawing.Point(10, 29);
            this.companylabel.Name = "companylabel";
            this.companylabel.Size = new System.Drawing.Size(170, 17);
            this.companylabel.TabIndex = 9;
            this.companylabel.Text = "Company    :  STI Caloocan";
            this.companylabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // datelabel
            // 
            this.datelabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.datelabel.AutoSize = true;
            this.datelabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.datelabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datelabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.datelabel.Location = new System.Drawing.Point(893, 8);
            this.datelabel.Name = "datelabel";
            this.datelabel.Size = new System.Drawing.Size(34, 17);
            this.datelabel.TabIndex = 12;
            this.datelabel.Text = "date";
            this.datelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // taxlabel
            // 
            this.taxlabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.taxlabel.AutoSize = true;
            this.taxlabel.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxlabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.taxlabel.Location = new System.Drawing.Point(840, 29);
            this.taxlabel.Name = "taxlabel";
            this.taxlabel.Size = new System.Drawing.Size(94, 17);
            this.taxlabel.TabIndex = 13;
            this.taxlabel.Text = "User  :  Admin";
            this.taxlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // basepanel
            // 
            this.basepanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.basepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.basepanel.Controls.Add(this.generatebutton);
            this.basepanel.Controls.Add(this.settingsPanel);
            this.basepanel.Controls.Add(this.instructionpanel);
            this.basepanel.Controls.Add(this.contbox);
            this.basepanel.Controls.Add(this.employeebox);
            this.basepanel.Controls.Add(this.deductbox);
            this.basepanel.Controls.Add(this.earningbox);
            this.basepanel.Controls.Add(this.taxlabel);
            this.basepanel.Controls.Add(this.datelabel);
            this.basepanel.Controls.Add(this.companylabel);
            this.basepanel.Controls.Add(this.payrolldatelabel);
            this.basepanel.Controls.Add(this.frequencylabel);
            this.basepanel.HorizontalScrollbarBarColor = true;
            this.basepanel.HorizontalScrollbarHighlightOnWheel = false;
            this.basepanel.HorizontalScrollbarSize = 10;
            this.basepanel.Location = new System.Drawing.Point(168, 28);
            this.basepanel.Name = "basepanel";
            this.basepanel.Size = new System.Drawing.Size(1082, 604);
            this.basepanel.TabIndex = 100;
            this.basepanel.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.basepanel.UseCustomBackColor = true;
            this.basepanel.VerticalScrollbarBarColor = true;
            this.basepanel.VerticalScrollbarHighlightOnWheel = false;
            this.basepanel.VerticalScrollbarSize = 10;
            this.basepanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseDown);
            this.basepanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseMove);
            // 
            // generatebutton
            // 
            this.generatebutton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.generatebutton.AnimationHoverSpeed = 0.07F;
            this.generatebutton.AnimationSpeed = 0.03F;
            this.generatebutton.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.generatebutton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.generatebutton.BorderSize = 2;
            this.generatebutton.CheckedBaseColor = System.Drawing.Color.Gray;
            this.generatebutton.CheckedBorderColor = System.Drawing.Color.Black;
            this.generatebutton.CheckedForeColor = System.Drawing.Color.White;
            this.generatebutton.CheckedImage = null;
            this.generatebutton.CheckedLineColor = System.Drawing.Color.DimGray;
            this.generatebutton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.generatebutton.FocusedColor = System.Drawing.Color.Empty;
            this.generatebutton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.generatebutton.ForeColor = System.Drawing.Color.White;
            this.generatebutton.Image = null;
            this.generatebutton.ImageSize = new System.Drawing.Size(20, 20);
            this.generatebutton.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.generatebutton.Location = new System.Drawing.Point(443, 479);
            this.generatebutton.Name = "generatebutton";
            this.generatebutton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.generatebutton.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            this.generatebutton.OnHoverForeColor = System.Drawing.Color.White;
            this.generatebutton.OnHoverImage = null;
            this.generatebutton.OnHoverLineColor = System.Drawing.Color.Transparent;
            this.generatebutton.OnPressedColor = System.Drawing.Color.Black;
            this.generatebutton.Size = new System.Drawing.Size(197, 44);
            this.generatebutton.TabIndex = 1002;
            this.generatebutton.Text = "GENERATE PAYSLIP";
            this.generatebutton.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.generatebutton.Click += new System.EventHandler(this.generatepayslip_Click);
            // 
            // settingsPanel
            // 
            this.settingsPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.settingsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.settingsPanel.Controls.Add(this.monokailabel);
            this.settingsPanel.Controls.Add(this.darkshadelabel);
            this.settingsPanel.Controls.Add(this.themeslabel);
            this.settingsPanel.Controls.Add(this.monokaitheme);
            this.settingsPanel.Controls.Add(this.darktheme);
            this.settingsPanel.Location = new System.Drawing.Point(895, 70);
            this.settingsPanel.Name = "settingsPanel";
            this.settingsPanel.Size = new System.Drawing.Size(187, 289);
            this.settingsPanel.TabIndex = 1001;
            this.settingsPanel.Visible = false;
            // 
            // monokailabel
            // 
            this.monokailabel.AutoSize = true;
            this.monokailabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monokailabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.monokailabel.Location = new System.Drawing.Point(6, 69);
            this.monokailabel.Name = "monokailabel";
            this.monokailabel.Size = new System.Drawing.Size(71, 21);
            this.monokailabel.TabIndex = 1005;
            this.monokailabel.Text = "Monokai";
            this.monokailabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // darkshadelabel
            // 
            this.darkshadelabel.AutoSize = true;
            this.darkshadelabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.darkshadelabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.darkshadelabel.Location = new System.Drawing.Point(6, 41);
            this.darkshadelabel.Name = "darkshadelabel";
            this.darkshadelabel.Size = new System.Drawing.Size(90, 21);
            this.darkshadelabel.TabIndex = 1004;
            this.darkshadelabel.Text = "Dark Shade";
            this.darkshadelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // themeslabel
            // 
            this.themeslabel.Dock = System.Windows.Forms.DockStyle.Top;
            this.themeslabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.themeslabel.ForeColor = System.Drawing.Color.White;
            this.themeslabel.Location = new System.Drawing.Point(0, 0);
            this.themeslabel.Name = "themeslabel";
            this.themeslabel.Size = new System.Drawing.Size(187, 25);
            this.themeslabel.TabIndex = 34;
            this.themeslabel.Text = "Themes";
            this.themeslabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // monokaitheme
            // 
            this.monokaitheme.BaseColor = System.Drawing.Color.Transparent;
            this.monokaitheme.CheckedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.monokaitheme.CheckedOnColor = System.Drawing.Color.White;
            this.monokaitheme.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.monokaitheme.Location = new System.Drawing.Point(135, 69);
            this.monokaitheme.Name = "monokaitheme";
            this.monokaitheme.Size = new System.Drawing.Size(40, 22);
            this.monokaitheme.TabIndex = 1003;
            this.monokaitheme.CheckedChanged += new System.EventHandler(this.monokai_CheckedChanged);
            // 
            // darktheme
            // 
            this.darktheme.BaseColor = System.Drawing.Color.Transparent;
            this.darktheme.CheckedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.darktheme.CheckedOnColor = System.Drawing.Color.White;
            this.darktheme.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.darktheme.Location = new System.Drawing.Point(135, 41);
            this.darktheme.Name = "darktheme";
            this.darktheme.Size = new System.Drawing.Size(40, 22);
            this.darktheme.TabIndex = 1002;
            this.darktheme.CheckedChanged += new System.EventHandler(this.darktheme_CheckedChanged);
            // 
            // instructionpanel
            // 
            this.instructionpanel.BackColor = System.Drawing.Color.Transparent;
            this.instructionpanel.BaseColor = System.Drawing.Color.Teal;
            this.instructionpanel.Controls.Add(this.instructionlabel);
            this.instructionpanel.Location = new System.Drawing.Point(326, 86);
            this.instructionpanel.Name = "instructionpanel";
            this.instructionpanel.Radius = 21;
            this.instructionpanel.Size = new System.Drawing.Size(427, 39);
            this.instructionpanel.TabIndex = 37;
            // 
            // instructionlabel
            // 
            this.instructionlabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.instructionlabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionlabel.ForeColor = System.Drawing.Color.White;
            this.instructionlabel.Location = new System.Drawing.Point(0, 0);
            this.instructionlabel.Name = "instructionlabel";
            this.instructionlabel.Size = new System.Drawing.Size(427, 39);
            this.instructionlabel.TabIndex = 32;
            this.instructionlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contbox
            // 
            this.contbox.BackColor = System.Drawing.Color.Transparent;
            this.contbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.contbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.contbox.Controls.Add(this.contphillabel);
            this.contbox.Controls.Add(this.contsssbox);
            this.contbox.Controls.Add(this.contphilbox);
            this.contbox.Controls.Add(this.contssslabel);
            this.contbox.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.contbox.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.contbox.LineTop = 35;
            this.contbox.Location = new System.Drawing.Point(18, 306);
            this.contbox.Name = "contbox";
            this.contbox.Size = new System.Drawing.Size(338, 146);
            this.contbox.TabIndex = 3;
            this.contbox.Text = "EMPLOYEE CONTRIBUTION";
            this.contbox.TextLocation = new System.Drawing.Point(10, 8);
            this.contbox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseDown);
            this.contbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseMove);
            // 
            // contphillabel
            // 
            this.contphillabel.AutoSize = true;
            this.contphillabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contphillabel.ForeColor = System.Drawing.Color.White;
            this.contphillabel.Location = new System.Drawing.Point(19, 100);
            this.contphillabel.Name = "contphillabel";
            this.contphillabel.Size = new System.Drawing.Size(79, 21);
            this.contphillabel.TabIndex = 29;
            this.contphillabel.Text = "Philhealth";
            this.contphillabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contsssbox
            // 
            this.contsssbox.BackColor = System.Drawing.Color.Transparent;
            this.contsssbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.contsssbox.BorderColor = System.Drawing.Color.Transparent;
            this.contsssbox.BorderSize = 1;
            this.contsssbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.contsssbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.contsssbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.contsssbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.contsssbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.contsssbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.contsssbox.Location = new System.Drawing.Point(121, 53);
            this.contsssbox.MaxLength = 6;
            this.contsssbox.Name = "contsssbox";
            this.contsssbox.PasswordChar = '\0';
            this.contsssbox.Radius = 2;
            this.contsssbox.Size = new System.Drawing.Size(199, 35);
            this.contsssbox.TabIndex = 0;
            this.contsssbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.contsssbox.Enter += new System.EventHandler(this.default_contboxcolor_MouseEnter);
            this.contsssbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.contsssbox_KeyPress);
            this.contsssbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.contsssbox_MouseMove);
            // 
            // contphilbox
            // 
            this.contphilbox.BackColor = System.Drawing.Color.Transparent;
            this.contphilbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.contphilbox.BorderColor = System.Drawing.Color.Transparent;
            this.contphilbox.BorderSize = 1;
            this.contphilbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.contphilbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.contphilbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.contphilbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.contphilbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.contphilbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.contphilbox.Location = new System.Drawing.Point(121, 93);
            this.contphilbox.MaxLength = 3;
            this.contphilbox.Name = "contphilbox";
            this.contphilbox.PasswordChar = '\0';
            this.contphilbox.Radius = 2;
            this.contphilbox.Size = new System.Drawing.Size(199, 35);
            this.contphilbox.TabIndex = 1;
            this.contphilbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.contphilbox.Enter += new System.EventHandler(this.default_contboxcolor_MouseEnter);
            this.contphilbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.contphilbox_KeyPress);
            this.contphilbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.contphilbox_MouseMove);
            // 
            // contssslabel
            // 
            this.contssslabel.AutoSize = true;
            this.contssslabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contssslabel.ForeColor = System.Drawing.Color.White;
            this.contssslabel.Location = new System.Drawing.Point(19, 60);
            this.contssslabel.Name = "contssslabel";
            this.contssslabel.Size = new System.Drawing.Size(37, 21);
            this.contssslabel.TabIndex = 31;
            this.contssslabel.Text = "SSS";
            this.contssslabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // employeebox
            // 
            this.employeebox.BackColor = System.Drawing.Color.Transparent;
            this.employeebox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.employeebox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.employeebox.Controls.Add(this.idlabel);
            this.employeebox.Controls.Add(this.namebox);
            this.employeebox.Controls.Add(this.idbox);
            this.employeebox.Controls.Add(this.namelabel);
            this.employeebox.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.employeebox.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.employeebox.LineTop = 35;
            this.employeebox.Location = new System.Drawing.Point(18, 143);
            this.employeebox.Name = "employeebox";
            this.employeebox.Size = new System.Drawing.Size(338, 146);
            this.employeebox.TabIndex = 0;
            this.employeebox.Text = "EMPLOYEE INFORMATION";
            this.employeebox.TextLocation = new System.Drawing.Point(10, 8);
            this.employeebox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseDown);
            this.employeebox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseMove);
            // 
            // idlabel
            // 
            this.idlabel.AutoSize = true;
            this.idlabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idlabel.ForeColor = System.Drawing.Color.White;
            this.idlabel.Location = new System.Drawing.Point(19, 100);
            this.idlabel.Name = "idlabel";
            this.idlabel.Size = new System.Drawing.Size(84, 21);
            this.idlabel.TabIndex = 2;
            this.idlabel.Text = "ID number";
            this.idlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // namebox
            // 
            this.namebox.BackColor = System.Drawing.Color.Transparent;
            this.namebox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.namebox.BorderColor = System.Drawing.Color.Transparent;
            this.namebox.BorderSize = 1;
            this.namebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.namebox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.namebox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.namebox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.namebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.namebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.namebox.Location = new System.Drawing.Point(121, 53);
            this.namebox.MaxLength = 50;
            this.namebox.Name = "namebox";
            this.namebox.PasswordChar = '\0';
            this.namebox.Radius = 2;
            this.namebox.Size = new System.Drawing.Size(199, 35);
            this.namebox.TabIndex = 0;
            this.namebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.namebox.Enter += new System.EventHandler(this.default_employboxcolor_MouseEnter);
            this.namebox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.namebox_KeyPress);
            this.namebox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.namebox_MouseMove);
            // 
            // idbox
            // 
            this.idbox.BackColor = System.Drawing.Color.Transparent;
            this.idbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.idbox.BorderColor = System.Drawing.Color.Transparent;
            this.idbox.BorderSize = 1;
            this.idbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.idbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.idbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.idbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.idbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.idbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.idbox.Location = new System.Drawing.Point(121, 93);
            this.idbox.MaxLength = 20;
            this.idbox.Name = "idbox";
            this.idbox.PasswordChar = '\0';
            this.idbox.Radius = 2;
            this.idbox.Size = new System.Drawing.Size(199, 35);
            this.idbox.TabIndex = 1;
            this.idbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.idbox.Enter += new System.EventHandler(this.default_employboxcolor_MouseEnter);
            this.idbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.basicbox_KeyPress);
            this.idbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.idbox_MouseMove);
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namelabel.ForeColor = System.Drawing.Color.White;
            this.namelabel.Location = new System.Drawing.Point(19, 60);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(52, 21);
            this.namelabel.TabIndex = 31;
            this.namelabel.Text = "Name";
            this.namelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // deductbox
            // 
            this.deductbox.BackColor = System.Drawing.Color.Transparent;
            this.deductbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.deductbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.deductbox.Controls.Add(this.otherlabel);
            this.deductbox.Controls.Add(this.loanbox);
            this.deductbox.Controls.Add(this.phillabel);
            this.deductbox.Controls.Add(this.sssbox);
            this.deductbox.Controls.Add(this.canteenlabel);
            this.deductbox.Controls.Add(this.othersbox);
            this.deductbox.Controls.Add(this.loanlabel);
            this.deductbox.Controls.Add(this.philbox);
            this.deductbox.Controls.Add(this.cashlabel);
            this.deductbox.Controls.Add(this.canteenbox);
            this.deductbox.Controls.Add(this.ssslabel);
            this.deductbox.Controls.Add(this.cashbox);
            this.deductbox.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deductbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.deductbox.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.deductbox.LineTop = 35;
            this.deductbox.Location = new System.Drawing.Point(724, 143);
            this.deductbox.Name = "deductbox";
            this.deductbox.Size = new System.Drawing.Size(338, 309);
            this.deductbox.TabIndex = 2;
            this.deductbox.Text = "DEDUCTIONS";
            this.deductbox.TextLocation = new System.Drawing.Point(10, 8);
            this.deductbox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseDown);
            this.deductbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseMove);
            // 
            // otherlabel
            // 
            this.otherlabel.AutoSize = true;
            this.otherlabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.otherlabel.ForeColor = System.Drawing.Color.White;
            this.otherlabel.Location = new System.Drawing.Point(19, 260);
            this.otherlabel.Name = "otherlabel";
            this.otherlabel.Size = new System.Drawing.Size(57, 21);
            this.otherlabel.TabIndex = 33;
            this.otherlabel.Text = "Others";
            this.otherlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // loanbox
            // 
            this.loanbox.BackColor = System.Drawing.Color.Transparent;
            this.loanbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.loanbox.BorderColor = System.Drawing.Color.Transparent;
            this.loanbox.BorderSize = 1;
            this.loanbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.loanbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.loanbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.loanbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.loanbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.loanbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.loanbox.Location = new System.Drawing.Point(119, 213);
            this.loanbox.MaxLength = 6;
            this.loanbox.Name = "loanbox";
            this.loanbox.PasswordChar = '\0';
            this.loanbox.Radius = 2;
            this.loanbox.Size = new System.Drawing.Size(199, 35);
            this.loanbox.TabIndex = 4;
            this.loanbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.loanbox.Enter += new System.EventHandler(this.default_deductboxcolor_MouseEnter);
            this.loanbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.loanbox_KeyPress);
            this.loanbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.loanbox_MouseMove);
            // 
            // phillabel
            // 
            this.phillabel.AutoSize = true;
            this.phillabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phillabel.ForeColor = System.Drawing.Color.White;
            this.phillabel.Location = new System.Drawing.Point(19, 97);
            this.phillabel.Name = "phillabel";
            this.phillabel.Size = new System.Drawing.Size(79, 21);
            this.phillabel.TabIndex = 29;
            this.phillabel.Text = "Philhealth";
            this.phillabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sssbox
            // 
            this.sssbox.BackColor = System.Drawing.Color.Transparent;
            this.sssbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sssbox.BorderColor = System.Drawing.Color.Transparent;
            this.sssbox.BorderSize = 1;
            this.sssbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sssbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.sssbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sssbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sssbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.sssbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.sssbox.Location = new System.Drawing.Point(119, 50);
            this.sssbox.MaxLength = 6;
            this.sssbox.Name = "sssbox";
            this.sssbox.PasswordChar = '\0';
            this.sssbox.Radius = 2;
            this.sssbox.Size = new System.Drawing.Size(199, 35);
            this.sssbox.TabIndex = 0;
            this.sssbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.sssbox.Enter += new System.EventHandler(this.default_deductboxcolor_MouseEnter);
            this.sssbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.sssbox_KeyPress);
            this.sssbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.sssbox_MouseMove);
            // 
            // canteenlabel
            // 
            this.canteenlabel.AutoSize = true;
            this.canteenlabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.canteenlabel.ForeColor = System.Drawing.Color.White;
            this.canteenlabel.Location = new System.Drawing.Point(19, 138);
            this.canteenlabel.Name = "canteenlabel";
            this.canteenlabel.Size = new System.Drawing.Size(67, 21);
            this.canteenlabel.TabIndex = 28;
            this.canteenlabel.Text = "Canteen";
            this.canteenlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // othersbox
            // 
            this.othersbox.BackColor = System.Drawing.Color.Transparent;
            this.othersbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.othersbox.BorderColor = System.Drawing.Color.Transparent;
            this.othersbox.BorderSize = 1;
            this.othersbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.othersbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.othersbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.othersbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.othersbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.othersbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.othersbox.Location = new System.Drawing.Point(119, 254);
            this.othersbox.MaxLength = 6;
            this.othersbox.Name = "othersbox";
            this.othersbox.PasswordChar = '\0';
            this.othersbox.Radius = 2;
            this.othersbox.Size = new System.Drawing.Size(199, 35);
            this.othersbox.TabIndex = 5;
            this.othersbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.othersbox.Enter += new System.EventHandler(this.default_deductboxcolor_MouseEnter);
            this.othersbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.othersbox_KeyPress);
            this.othersbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.othersbox_MouseMove);
            // 
            // loanlabel
            // 
            this.loanlabel.AutoSize = true;
            this.loanlabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loanlabel.ForeColor = System.Drawing.Color.White;
            this.loanlabel.Location = new System.Drawing.Point(19, 220);
            this.loanlabel.Name = "loanlabel";
            this.loanlabel.Size = new System.Drawing.Size(51, 21);
            this.loanlabel.TabIndex = 32;
            this.loanlabel.Text = "Loans";
            this.loanlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // philbox
            // 
            this.philbox.BackColor = System.Drawing.Color.Transparent;
            this.philbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.philbox.BorderColor = System.Drawing.Color.Transparent;
            this.philbox.BorderSize = 1;
            this.philbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.philbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.philbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.philbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.philbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.philbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.philbox.Location = new System.Drawing.Point(119, 90);
            this.philbox.MaxLength = 6;
            this.philbox.Name = "philbox";
            this.philbox.PasswordChar = '\0';
            this.philbox.Radius = 2;
            this.philbox.Size = new System.Drawing.Size(199, 35);
            this.philbox.TabIndex = 1;
            this.philbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.philbox.Enter += new System.EventHandler(this.default_deductboxcolor_MouseEnter);
            this.philbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.philbox_KeyPress);
            this.philbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.philbox_MouseMove);
            // 
            // cashlabel
            // 
            this.cashlabel.AutoSize = true;
            this.cashlabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cashlabel.ForeColor = System.Drawing.Color.White;
            this.cashlabel.Location = new System.Drawing.Point(19, 180);
            this.cashlabel.Name = "cashlabel";
            this.cashlabel.Size = new System.Drawing.Size(75, 21);
            this.cashlabel.TabIndex = 30;
            this.cashlabel.Text = "Cash Adv";
            this.cashlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // canteenbox
            // 
            this.canteenbox.BackColor = System.Drawing.Color.Transparent;
            this.canteenbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.canteenbox.BorderColor = System.Drawing.Color.Transparent;
            this.canteenbox.BorderSize = 1;
            this.canteenbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.canteenbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.canteenbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.canteenbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.canteenbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.canteenbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.canteenbox.Location = new System.Drawing.Point(119, 131);
            this.canteenbox.MaxLength = 6;
            this.canteenbox.Name = "canteenbox";
            this.canteenbox.PasswordChar = '\0';
            this.canteenbox.Radius = 2;
            this.canteenbox.Size = new System.Drawing.Size(199, 35);
            this.canteenbox.TabIndex = 2;
            this.canteenbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.canteenbox.Enter += new System.EventHandler(this.default_deductboxcolor_MouseEnter);
            this.canteenbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.canteenbox_KeyPress);
            this.canteenbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.canteenbox_MouseMove);
            // 
            // ssslabel
            // 
            this.ssslabel.AutoSize = true;
            this.ssslabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssslabel.ForeColor = System.Drawing.Color.White;
            this.ssslabel.Location = new System.Drawing.Point(19, 57);
            this.ssslabel.Name = "ssslabel";
            this.ssslabel.Size = new System.Drawing.Size(37, 21);
            this.ssslabel.TabIndex = 31;
            this.ssslabel.Text = "SSS";
            this.ssslabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cashbox
            // 
            this.cashbox.BackColor = System.Drawing.Color.Transparent;
            this.cashbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cashbox.BorderColor = System.Drawing.Color.Transparent;
            this.cashbox.BorderSize = 1;
            this.cashbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cashbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.cashbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cashbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cashbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cashbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.cashbox.Location = new System.Drawing.Point(119, 172);
            this.cashbox.MaxLength = 6;
            this.cashbox.Name = "cashbox";
            this.cashbox.PasswordChar = '\0';
            this.cashbox.Radius = 2;
            this.cashbox.Size = new System.Drawing.Size(199, 35);
            this.cashbox.TabIndex = 3;
            this.cashbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cashbox.Enter += new System.EventHandler(this.default_deductboxcolor_MouseEnter);
            this.cashbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cashbox_KeyPress);
            this.cashbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cashbox_MouseMove);
            // 
            // earningbox
            // 
            this.earningbox.BackColor = System.Drawing.Color.Transparent;
            this.earningbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.earningbox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.earningbox.Controls.Add(this.latelabel);
            this.earningbox.Controls.Add(this.absentbox);
            this.earningbox.Controls.Add(this.basiclabel);
            this.earningbox.Controls.Add(this.ratebox);
            this.earningbox.Controls.Add(this.overtimelabel);
            this.earningbox.Controls.Add(this.latebox);
            this.earningbox.Controls.Add(this.absentlabel);
            this.earningbox.Controls.Add(this.basicbox);
            this.earningbox.Controls.Add(this.undertimelabel);
            this.earningbox.Controls.Add(this.overtimebox);
            this.earningbox.Controls.Add(this.ratelabel);
            this.earningbox.Controls.Add(this.undertimebox);
            this.earningbox.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.earningbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.earningbox.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(108)))), ((int)(((byte)(108)))));
            this.earningbox.LineTop = 35;
            this.earningbox.Location = new System.Drawing.Point(371, 143);
            this.earningbox.Name = "earningbox";
            this.earningbox.Size = new System.Drawing.Size(338, 309);
            this.earningbox.TabIndex = 1;
            this.earningbox.Text = "EARNINGS";
            this.earningbox.TextLocation = new System.Drawing.Point(10, 8);
            this.earningbox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseDown);
            this.earningbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseMove);
            // 
            // latelabel
            // 
            this.latelabel.AutoSize = true;
            this.latelabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.latelabel.ForeColor = System.Drawing.Color.White;
            this.latelabel.Location = new System.Drawing.Point(19, 260);
            this.latelabel.Name = "latelabel";
            this.latelabel.Size = new System.Drawing.Size(74, 21);
            this.latelabel.TabIndex = 33;
            this.latelabel.Text = "Tardiness";
            this.latelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // absentbox
            // 
            this.absentbox.BackColor = System.Drawing.Color.Transparent;
            this.absentbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.absentbox.BorderColor = System.Drawing.Color.Transparent;
            this.absentbox.BorderSize = 1;
            this.absentbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.absentbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.absentbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.absentbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.absentbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.absentbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.absentbox.Location = new System.Drawing.Point(121, 213);
            this.absentbox.MaxLength = 1;
            this.absentbox.Name = "absentbox";
            this.absentbox.PasswordChar = '\0';
            this.absentbox.Radius = 2;
            this.absentbox.Size = new System.Drawing.Size(199, 35);
            this.absentbox.TabIndex = 4;
            this.absentbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.absentbox.Enter += new System.EventHandler(this.default_earningboxcolor_MouseEnter);
            this.absentbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.basicbox_KeyPress);
            this.absentbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.absentbox_MouseMove);
            // 
            // basiclabel
            // 
            this.basiclabel.AutoSize = true;
            this.basiclabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basiclabel.ForeColor = System.Drawing.Color.White;
            this.basiclabel.Location = new System.Drawing.Point(19, 97);
            this.basiclabel.Name = "basiclabel";
            this.basiclabel.Size = new System.Drawing.Size(45, 21);
            this.basiclabel.TabIndex = 29;
            this.basiclabel.Text = "Basic";
            this.basiclabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ratebox
            // 
            this.ratebox.BackColor = System.Drawing.Color.Transparent;
            this.ratebox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ratebox.BorderColor = System.Drawing.Color.Transparent;
            this.ratebox.BorderSize = 1;
            this.ratebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ratebox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.ratebox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ratebox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ratebox.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ratebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.ratebox.Location = new System.Drawing.Point(121, 50);
            this.ratebox.MaxLength = 6;
            this.ratebox.Name = "ratebox";
            this.ratebox.PasswordChar = '\0';
            this.ratebox.Radius = 2;
            this.ratebox.Size = new System.Drawing.Size(199, 35);
            this.ratebox.TabIndex = 0;
            this.ratebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ratebox.Enter += new System.EventHandler(this.default_earningboxcolor_MouseEnter);
            this.ratebox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ratebox_KeyPress);
            this.ratebox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ratebox_MouseMove);
            // 
            // overtimelabel
            // 
            this.overtimelabel.AutoSize = true;
            this.overtimelabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.overtimelabel.ForeColor = System.Drawing.Color.White;
            this.overtimelabel.Location = new System.Drawing.Point(19, 138);
            this.overtimelabel.Name = "overtimelabel";
            this.overtimelabel.Size = new System.Drawing.Size(75, 21);
            this.overtimelabel.TabIndex = 28;
            this.overtimelabel.Text = "Overtime";
            this.overtimelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // latebox
            // 
            this.latebox.BackColor = System.Drawing.Color.Transparent;
            this.latebox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.latebox.BorderColor = System.Drawing.Color.Transparent;
            this.latebox.BorderSize = 1;
            this.latebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.latebox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.latebox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.latebox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.latebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.latebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.latebox.Location = new System.Drawing.Point(121, 254);
            this.latebox.MaxLength = 3;
            this.latebox.Name = "latebox";
            this.latebox.PasswordChar = '\0';
            this.latebox.Radius = 2;
            this.latebox.Size = new System.Drawing.Size(199, 35);
            this.latebox.TabIndex = 5;
            this.latebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.latebox.Enter += new System.EventHandler(this.default_earningboxcolor_MouseEnter);
            this.latebox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.basicbox_KeyPress);
            this.latebox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.latebox_MouseMove);
            // 
            // absentlabel
            // 
            this.absentlabel.AutoSize = true;
            this.absentlabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.absentlabel.ForeColor = System.Drawing.Color.White;
            this.absentlabel.Location = new System.Drawing.Point(19, 220);
            this.absentlabel.Name = "absentlabel";
            this.absentlabel.Size = new System.Drawing.Size(75, 21);
            this.absentlabel.TabIndex = 32;
            this.absentlabel.Text = "Absences";
            this.absentlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // basicbox
            // 
            this.basicbox.BackColor = System.Drawing.Color.Transparent;
            this.basicbox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.basicbox.BorderColor = System.Drawing.Color.Transparent;
            this.basicbox.BorderSize = 1;
            this.basicbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.basicbox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.basicbox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.basicbox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.basicbox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.basicbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.basicbox.Location = new System.Drawing.Point(121, 90);
            this.basicbox.MaxLength = 3;
            this.basicbox.Name = "basicbox";
            this.basicbox.PasswordChar = '\0';
            this.basicbox.Radius = 2;
            this.basicbox.Size = new System.Drawing.Size(199, 35);
            this.basicbox.TabIndex = 1;
            this.basicbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.basicbox.Enter += new System.EventHandler(this.default_earningboxcolor_MouseEnter);
            this.basicbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.basicbox_KeyPress);
            this.basicbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.basicbox_MouseMove);
            // 
            // undertimelabel
            // 
            this.undertimelabel.AutoSize = true;
            this.undertimelabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.undertimelabel.ForeColor = System.Drawing.Color.White;
            this.undertimelabel.Location = new System.Drawing.Point(19, 180);
            this.undertimelabel.Name = "undertimelabel";
            this.undertimelabel.Size = new System.Drawing.Size(84, 21);
            this.undertimelabel.TabIndex = 30;
            this.undertimelabel.Text = "Undertime";
            this.undertimelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // overtimebox
            // 
            this.overtimebox.BackColor = System.Drawing.Color.Transparent;
            this.overtimebox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.overtimebox.BorderColor = System.Drawing.Color.Transparent;
            this.overtimebox.BorderSize = 1;
            this.overtimebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.overtimebox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.overtimebox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.overtimebox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.overtimebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.overtimebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.overtimebox.Location = new System.Drawing.Point(121, 131);
            this.overtimebox.MaxLength = 2;
            this.overtimebox.Name = "overtimebox";
            this.overtimebox.PasswordChar = '\0';
            this.overtimebox.Radius = 2;
            this.overtimebox.Size = new System.Drawing.Size(199, 35);
            this.overtimebox.TabIndex = 2;
            this.overtimebox.TabStop = false;
            this.overtimebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.overtimebox.Enter += new System.EventHandler(this.default_earningboxcolor_MouseEnter);
            this.overtimebox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.basicbox_KeyPress);
            this.overtimebox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.overtimebox_MouseMove);
            // 
            // ratelabel
            // 
            this.ratelabel.AutoSize = true;
            this.ratelabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ratelabel.ForeColor = System.Drawing.Color.White;
            this.ratelabel.Location = new System.Drawing.Point(19, 57);
            this.ratelabel.Name = "ratelabel";
            this.ratelabel.Size = new System.Drawing.Size(41, 21);
            this.ratelabel.TabIndex = 31;
            this.ratelabel.Text = "Rate";
            this.ratelabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // undertimebox
            // 
            this.undertimebox.BackColor = System.Drawing.Color.Transparent;
            this.undertimebox.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.undertimebox.BorderColor = System.Drawing.Color.Transparent;
            this.undertimebox.BorderSize = 1;
            this.undertimebox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.undertimebox.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.undertimebox.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.undertimebox.FocusedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.undertimebox.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.undertimebox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.undertimebox.Location = new System.Drawing.Point(121, 172);
            this.undertimebox.MaxLength = 2;
            this.undertimebox.Name = "undertimebox";
            this.undertimebox.PasswordChar = '\0';
            this.undertimebox.Radius = 2;
            this.undertimebox.Size = new System.Drawing.Size(199, 35);
            this.undertimebox.TabIndex = 3;
            this.undertimebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.undertimebox.Enter += new System.EventHandler(this.default_earningboxcolor_MouseEnter);
            this.undertimebox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.basicbox_KeyPress);
            this.undertimebox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.undertimebox_MouseMove);
            // 
            // menupanel
            // 
            this.menupanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.menupanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.menupanel.Controls.Add(this.employeeButton);
            this.menupanel.Controls.Add(this.newButton);
            this.menupanel.Controls.Add(this.printedButton);
            this.menupanel.Controls.Add(this.recordButton);
            this.menupanel.Controls.Add(this.logoutButton);
            this.menupanel.Location = new System.Drawing.Point(0, 28);
            this.menupanel.Name = "menupanel";
            this.menupanel.Size = new System.Drawing.Size(168, 657);
            this.menupanel.TabIndex = 31;
            // 
            // employeeButton
            // 
            this.employeeButton.AnimationHoverSpeed = 0.1F;
            this.employeeButton.AnimationSpeed = 0.1F;
            this.employeeButton.BackColor = System.Drawing.Color.Transparent;
            this.employeeButton.BaseColor = System.Drawing.Color.Transparent;
            this.employeeButton.BorderColor = System.Drawing.Color.Black;
            this.employeeButton.CheckedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.employeeButton.CheckedBorderColor = System.Drawing.Color.Transparent;
            this.employeeButton.CheckedForeColor = System.Drawing.Color.White;
            this.employeeButton.CheckedImage = ((System.Drawing.Image)(resources.GetObject("employeeButton.CheckedImage")));
            this.employeeButton.CheckedLineColor = System.Drawing.Color.Transparent;
            this.employeeButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.employeeButton.FocusedColor = System.Drawing.Color.Empty;
            this.employeeButton.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.employeeButton.Image = global::payrollgenerator.Properties.Resources.employees_white;
            this.employeeButton.ImageOffsetX = 5;
            this.employeeButton.ImageSize = new System.Drawing.Size(27, 27);
            this.employeeButton.LineColor = System.Drawing.Color.Transparent;
            this.employeeButton.LineLeft = 10;
            this.employeeButton.Location = new System.Drawing.Point(0, 308);
            this.employeeButton.Name = "employeeButton";
            this.employeeButton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.employeeButton.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.employeeButton.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.employeeButton.OnHoverImage = global::payrollgenerator.Properties.Resources.employees_blue;
            this.employeeButton.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.employeeButton.OnPressedColor = System.Drawing.Color.DarkGreen;
            this.employeeButton.Size = new System.Drawing.Size(168, 35);
            this.employeeButton.TabIndex = 32;
            this.employeeButton.TabStop = false;
            this.employeeButton.Text = "EMPLOYEES";
            this.employeeButton.TextOffsetX = 3;
            // 
            // newButton
            // 
            this.newButton.AnimationHoverSpeed = 0.1F;
            this.newButton.AnimationSpeed = 0.1F;
            this.newButton.BackColor = System.Drawing.Color.Transparent;
            this.newButton.BaseColor = System.Drawing.Color.Transparent;
            this.newButton.BorderColor = System.Drawing.Color.Black;
            this.newButton.CheckedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.newButton.CheckedBorderColor = System.Drawing.Color.Transparent;
            this.newButton.CheckedForeColor = System.Drawing.Color.White;
            this.newButton.CheckedImage = ((System.Drawing.Image)(resources.GetObject("newButton.CheckedImage")));
            this.newButton.CheckedLineColor = System.Drawing.Color.Transparent;
            this.newButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.newButton.FocusedColor = System.Drawing.Color.Empty;
            this.newButton.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.newButton.Image = global::payrollgenerator.Properties.Resources.add_property_48px;
            this.newButton.ImageOffsetX = 5;
            this.newButton.ImageSize = new System.Drawing.Size(27, 27);
            this.newButton.LineColor = System.Drawing.Color.Transparent;
            this.newButton.LineLeft = 10;
            this.newButton.Location = new System.Drawing.Point(0, 144);
            this.newButton.Name = "newButton";
            this.newButton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.newButton.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.newButton.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.newButton.OnHoverImage = global::payrollgenerator.Properties.Resources.new_record_blue;
            this.newButton.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.newButton.OnPressedColor = System.Drawing.Color.DarkGreen;
            this.newButton.Size = new System.Drawing.Size(168, 35);
            this.newButton.TabIndex = 31;
            this.newButton.TabStop = false;
            this.newButton.Text = "ADD NEW";
            this.newButton.TextOffsetX = 3;
            // 
            // printedButton
            // 
            this.printedButton.AnimationHoverSpeed = 0.1F;
            this.printedButton.AnimationSpeed = 0.1F;
            this.printedButton.BackColor = System.Drawing.Color.Transparent;
            this.printedButton.BaseColor = System.Drawing.Color.Transparent;
            this.printedButton.BorderColor = System.Drawing.Color.Black;
            this.printedButton.CheckedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.printedButton.CheckedBorderColor = System.Drawing.Color.Transparent;
            this.printedButton.CheckedForeColor = System.Drawing.Color.White;
            this.printedButton.CheckedImage = ((System.Drawing.Image)(resources.GetObject("printedButton.CheckedImage")));
            this.printedButton.CheckedLineColor = System.Drawing.Color.Transparent;
            this.printedButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.printedButton.FocusedColor = System.Drawing.Color.Empty;
            this.printedButton.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printedButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.printedButton.Image = global::payrollgenerator.Properties.Resources.printer;
            this.printedButton.ImageOffsetX = 5;
            this.printedButton.ImageSize = new System.Drawing.Size(27, 27);
            this.printedButton.LineColor = System.Drawing.Color.Transparent;
            this.printedButton.LineLeft = 10;
            this.printedButton.Location = new System.Drawing.Point(0, 226);
            this.printedButton.Name = "printedButton";
            this.printedButton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.printedButton.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.printedButton.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.printedButton.OnHoverImage = global::payrollgenerator.Properties.Resources.output_blue;
            this.printedButton.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.printedButton.OnPressedColor = System.Drawing.Color.DarkGreen;
            this.printedButton.Size = new System.Drawing.Size(168, 35);
            this.printedButton.TabIndex = 30;
            this.printedButton.TabStop = false;
            this.printedButton.Text = "OUTPUT";
            this.printedButton.TextOffsetX = 3;
            this.printedButton.Click += new System.EventHandler(this.printedButton_Click);
            // 
            // recordButton
            // 
            this.recordButton.AnimationHoverSpeed = 0.1F;
            this.recordButton.AnimationSpeed = 0.1F;
            this.recordButton.BackColor = System.Drawing.Color.Transparent;
            this.recordButton.BaseColor = System.Drawing.Color.Transparent;
            this.recordButton.BorderColor = System.Drawing.Color.Black;
            this.recordButton.CheckedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.recordButton.CheckedBorderColor = System.Drawing.Color.Transparent;
            this.recordButton.CheckedForeColor = System.Drawing.Color.White;
            this.recordButton.CheckedImage = ((System.Drawing.Image)(resources.GetObject("recordButton.CheckedImage")));
            this.recordButton.CheckedLineColor = System.Drawing.Color.Transparent;
            this.recordButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.recordButton.FocusedColor = System.Drawing.Color.Empty;
            this.recordButton.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recordButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.recordButton.Image = global::payrollgenerator.Properties.Resources.bulleted_list_48px;
            this.recordButton.ImageOffsetX = 5;
            this.recordButton.ImageSize = new System.Drawing.Size(27, 27);
            this.recordButton.LineColor = System.Drawing.Color.Transparent;
            this.recordButton.LineLeft = 10;
            this.recordButton.Location = new System.Drawing.Point(0, 185);
            this.recordButton.Name = "recordButton";
            this.recordButton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.recordButton.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.recordButton.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.recordButton.OnHoverImage = global::payrollgenerator.Properties.Resources.records_blue;
            this.recordButton.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.recordButton.OnPressedColor = System.Drawing.Color.DarkGreen;
            this.recordButton.Size = new System.Drawing.Size(168, 35);
            this.recordButton.TabIndex = 28;
            this.recordButton.TabStop = false;
            this.recordButton.Text = "RECORDS";
            this.recordButton.TextOffsetX = 3;
            // 
            // logoutButton
            // 
            this.logoutButton.AnimationHoverSpeed = 0.1F;
            this.logoutButton.AnimationSpeed = 0.1F;
            this.logoutButton.BackColor = System.Drawing.Color.Transparent;
            this.logoutButton.BaseColor = System.Drawing.Color.Transparent;
            this.logoutButton.BorderColor = System.Drawing.Color.Black;
            this.logoutButton.CheckedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.logoutButton.CheckedBorderColor = System.Drawing.Color.Transparent;
            this.logoutButton.CheckedForeColor = System.Drawing.Color.White;
            this.logoutButton.CheckedImage = ((System.Drawing.Image)(resources.GetObject("logoutButton.CheckedImage")));
            this.logoutButton.CheckedLineColor = System.Drawing.Color.Transparent;
            this.logoutButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.logoutButton.FocusedColor = System.Drawing.Color.Empty;
            this.logoutButton.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.logoutButton.Image = global::payrollgenerator.Properties.Resources.exit_white;
            this.logoutButton.ImageOffsetX = 5;
            this.logoutButton.ImageSize = new System.Drawing.Size(27, 27);
            this.logoutButton.LineColor = System.Drawing.Color.Transparent;
            this.logoutButton.LineLeft = 10;
            this.logoutButton.Location = new System.Drawing.Point(0, 267);
            this.logoutButton.Name = "logoutButton";
            this.logoutButton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logoutButton.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.logoutButton.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.logoutButton.OnHoverImage = global::payrollgenerator.Properties.Resources.exit_blue;
            this.logoutButton.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.logoutButton.OnPressedColor = System.Drawing.Color.DarkGreen;
            this.logoutButton.Size = new System.Drawing.Size(168, 35);
            this.logoutButton.TabIndex = 29;
            this.logoutButton.TabStop = false;
            this.logoutButton.Text = "LOGOUT";
            this.logoutButton.TextOffsetX = 3;
            this.logoutButton.Click += new System.EventHandler(this.logoutButton_Click);
            // 
            // controlpanel
            // 
            this.controlpanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.controlpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.controlpanel.Controls.Add(this.minimizebutton);
            this.controlpanel.Controls.Add(this.settingsbutton);
            this.controlpanel.Controls.Add(this.gunaLabel1);
            this.controlpanel.Location = new System.Drawing.Point(0, 0);
            this.controlpanel.Name = "controlpanel";
            this.controlpanel.Size = new System.Drawing.Size(1250, 28);
            this.controlpanel.TabIndex = 29;
            this.controlpanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseDown);
            this.controlpanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseMove);
            // 
            // minimizebutton
            // 
            this.minimizebutton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.minimizebutton.AnimationHoverSpeed = 0.07F;
            this.minimizebutton.AnimationSpeed = 0.03F;
            this.minimizebutton.BaseColor = System.Drawing.Color.Transparent;
            this.minimizebutton.BorderColor = System.Drawing.Color.Black;
            this.minimizebutton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.minimizebutton.FocusedColor = System.Drawing.Color.Empty;
            this.minimizebutton.Font = new System.Drawing.Font("Segoe UI Light", 15.75F);
            this.minimizebutton.ForeColor = System.Drawing.Color.White;
            this.minimizebutton.Image = ((System.Drawing.Image)(resources.GetObject("minimizebutton.Image")));
            this.minimizebutton.ImageSize = new System.Drawing.Size(27, 27);
            this.minimizebutton.Location = new System.Drawing.Point(1222, 1);
            this.minimizebutton.Name = "minimizebutton";
            this.minimizebutton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.minimizebutton.OnHoverBorderColor = System.Drawing.Color.Black;
            this.minimizebutton.OnHoverForeColor = System.Drawing.Color.White;
            this.minimizebutton.OnHoverImage = ((System.Drawing.Image)(resources.GetObject("minimizebutton.OnHoverImage")));
            this.minimizebutton.OnPressedColor = System.Drawing.Color.Black;
            this.minimizebutton.Size = new System.Drawing.Size(27, 27);
            this.minimizebutton.TabIndex = 38;
            this.minimizebutton.TabStop = false;
            this.minimizebutton.Click += new System.EventHandler(this.minimizebutton_Click);
            // 
            // settingsbutton
            // 
            this.settingsbutton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.settingsbutton.AnimationHoverSpeed = 0.07F;
            this.settingsbutton.AnimationSpeed = 0.03F;
            this.settingsbutton.BaseColor = System.Drawing.Color.Transparent;
            this.settingsbutton.BorderColor = System.Drawing.Color.Black;
            this.settingsbutton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.settingsbutton.FocusedColor = System.Drawing.Color.Empty;
            this.settingsbutton.Font = new System.Drawing.Font("Segoe UI Light", 15.75F);
            this.settingsbutton.ForeColor = System.Drawing.Color.White;
            this.settingsbutton.Image = ((System.Drawing.Image)(resources.GetObject("settingsbutton.Image")));
            this.settingsbutton.ImageSize = new System.Drawing.Size(27, 27);
            this.settingsbutton.Location = new System.Drawing.Point(1194, 1);
            this.settingsbutton.Name = "settingsbutton";
            this.settingsbutton.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.settingsbutton.OnHoverBorderColor = System.Drawing.Color.Black;
            this.settingsbutton.OnHoverForeColor = System.Drawing.Color.White;
            this.settingsbutton.OnHoverImage = ((System.Drawing.Image)(resources.GetObject("settingsbutton.OnHoverImage")));
            this.settingsbutton.OnPressedColor = System.Drawing.Color.Black;
            this.settingsbutton.Size = new System.Drawing.Size(27, 27);
            this.settingsbutton.TabIndex = 37;
            this.settingsbutton.TabStop = false;
            this.settingsbutton.Click += new System.EventHandler(this.settingsbutton_Click);
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.gunaLabel1.Location = new System.Drawing.Point(6, 5);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(206, 17);
            this.gunaLabel1.TabIndex = 0;
            this.gunaLabel1.Text = "Payroll System v1.1 by Sam Tutor";
            this.gunaLabel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseDown);
            this.gunaLabel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseMove);
            // 
            // mainpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1250, 654);
            this.ControlBox = false;
            this.Controls.Add(this.menupanel);
            this.Controls.Add(this.basepanel);
            this.Controls.Add(this.controlpanel);
            this.DisplayHeader = false;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(776, 532);
            this.Name = "mainpage";
            this.Padding = new System.Windows.Forms.Padding(20, 30, 20, 20);
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.database_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragform_MouseMove);
            this.basepanel.ResumeLayout(false);
            this.basepanel.PerformLayout();
            this.settingsPanel.ResumeLayout(false);
            this.settingsPanel.PerformLayout();
            this.instructionpanel.ResumeLayout(false);
            this.contbox.ResumeLayout(false);
            this.contbox.PerformLayout();
            this.employeebox.ResumeLayout(false);
            this.employeebox.PerformLayout();
            this.deductbox.ResumeLayout(false);
            this.deductbox.PerformLayout();
            this.earningbox.ResumeLayout(false);
            this.earningbox.PerformLayout();
            this.menupanel.ResumeLayout(false);
            this.controlpanel.ResumeLayout(false);
            this.controlpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label frequencylabel;
        private System.Windows.Forms.Label payrolldatelabel;
        private System.Windows.Forms.Label companylabel;
        private System.Windows.Forms.Label datelabel;
        private System.Windows.Forms.Label taxlabel;
        private MetroFramework.Controls.MetroPanel basepanel;
        private Guna.UI.WinForms.GunaGroupBox earningbox;
        private Guna.UI.WinForms.GunaAdvenceButton recordButton;
        private Guna.UI.WinForms.GunaAdvenceButton logoutButton;
        private Guna.UI.WinForms.GunaAdvenceButton printedButton;
        private Guna.UI.WinForms.GunaPanel menupanel;
        private Guna.UI.WinForms.GunaAdvenceButton newButton;
        private Guna.UI.WinForms.GunaPanel controlpanel;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaTextBox ratebox;
        private Guna.UI.WinForms.GunaTextBox latebox;
        private Guna.UI.WinForms.GunaTextBox absentbox;
        private Guna.UI.WinForms.GunaTextBox undertimebox;
        private Guna.UI.WinForms.GunaTextBox overtimebox;
        private Guna.UI.WinForms.GunaTextBox basicbox;
        private System.Windows.Forms.Label latelabel;
        private System.Windows.Forms.Label basiclabel;
        private System.Windows.Forms.Label overtimelabel;
        private System.Windows.Forms.Label absentlabel;
        private System.Windows.Forms.Label undertimelabel;
        private System.Windows.Forms.Label ratelabel;
        private Guna.UI.WinForms.GunaGroupBox deductbox;
        private System.Windows.Forms.Label otherlabel;
        private Guna.UI.WinForms.GunaTextBox loanbox;
        private System.Windows.Forms.Label phillabel;
        private Guna.UI.WinForms.GunaTextBox sssbox;
        private System.Windows.Forms.Label canteenlabel;
        private Guna.UI.WinForms.GunaTextBox othersbox;
        private System.Windows.Forms.Label loanlabel;
        private Guna.UI.WinForms.GunaTextBox philbox;
        private System.Windows.Forms.Label cashlabel;
        private Guna.UI.WinForms.GunaTextBox canteenbox;
        private System.Windows.Forms.Label ssslabel;
        private Guna.UI.WinForms.GunaTextBox cashbox;
        private Guna.UI.WinForms.GunaGroupBox contbox;
        private System.Windows.Forms.Label contphillabel;
        private Guna.UI.WinForms.GunaTextBox contsssbox;
        private Guna.UI.WinForms.GunaTextBox contphilbox;
        private System.Windows.Forms.Label contssslabel;
        private Guna.UI.WinForms.GunaGroupBox employeebox;
        private System.Windows.Forms.Label idlabel;
        private Guna.UI.WinForms.GunaTextBox namebox;
        private Guna.UI.WinForms.GunaTextBox idbox;
        private System.Windows.Forms.Label namelabel;
        private Guna.UI.WinForms.GunaTileButton settingsbutton;
        private Guna.UI.WinForms.GunaTileButton minimizebutton;
        private Guna.UI.WinForms.GunaWinSwitch darktheme;
        private System.Windows.Forms.Label themeslabel;
        private Guna.UI.WinForms.GunaWinSwitch monokaitheme;
        private Guna.UI.WinForms.GunaPanel settingsPanel;
        private System.Windows.Forms.Label monokailabel;
        private System.Windows.Forms.Label darkshadelabel;
        private Guna.UI.WinForms.GunaElipsePanel instructionpanel;
        private System.Windows.Forms.Label instructionlabel;
        private Guna.UI.WinForms.GunaAdvenceButton generatebutton;
        private Guna.UI.WinForms.GunaAdvenceButton employeeButton;
    }
}