﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace payrollgenerator
{
    public partial class saved : MetroFramework.Forms.MetroForm
    {
        public static string error = "";

        public saved()
        {
            InitializeComponent();
        }

        public Bitmap bitmapsave { get; set; }

        private void saved_Load(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Asterisk.Play();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String filename = metroTextBox2.Text;
            String pathname = "D:\\Saved_Payroll_";

            if (string.IsNullOrWhiteSpace(metroTextBox2.Text))
            {
                error = "Enter File Name!";
                existing existing = new existing();
                existing.ShowDialog();

            }
            else if (File.Exists(pathname + filename + ".png"))
            {
                error = "File Already Existing!";
                existing existing = new existing();
                existing.ShowDialog();
            }
            else
            {
                bitmapsave.Save(pathname + filename + ".png", ImageFormat.Png);

                this.Dispose();

                mainpage mainpage = new mainpage();
                mainpage.Show();
                Application.OpenForms["payslip"].Dispose();

                openfolder openfolder = new openfolder();
                openfolder.ShowDialog();
            }   
        }

        private void metroTextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '_' && e.KeyChar != '-';
        }
    }
}
