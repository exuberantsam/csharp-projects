﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace payrollgenerator
{
    public partial class existing : MetroFramework.Forms.MetroForm
    {
        public existing()
        {
            InitializeComponent();
        }

        private void existing_Load(object sender, EventArgs e)
        {
            System.Media.SystemSounds.Hand.Play();
            label1.Text = saved.error;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
