﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace payrollgenerator
{
    public partial class payslip : MetroFramework.Forms.MetroForm
    {
        public payslip()
        {
            InitializeComponent();
        }

        
        // Earnings
        public int hourswork { get; set; }
        public float ratexbasic { get; set; }
        public int overtimehours { get; set; }
        public float overxrate { get; set; }  
        public int undertimehours { get; set; }
        public float underxrate { get; set; }
        public int absentdays { get; set; }
        public float absentxrate { get; set; }
        public int latemins { get; set; }
        public float latexrate { get; set; }
        public float totalearn { get; set; }
        // Deductions
        public float sss { get; set; }
        public float philhealth { get; set; }
        public float canteen { get; set; }
        public float cashadv { get; set; }
        public float loans { get; set; }
        public float others { get; set; }
        public float totaldeduct { get; set; }
        // Contributions
        public float contsss { get; set; }
        public float contphilhealth { get; set; }
        public float totalcontri { get; set; }
        // Take Home
        public float takehomepay { get; set; }


        public void payslip_Load(object sender, EventArgs e)
        {

            label78.Text = "PHP " + String.Format("{0:n}", takehomepay);
            // Deductions
            label74.Text = String.Format("{0:n}", totalcontri);
            label69.Text = String.Format("{0:n}", contsss);
            label58.Text = String.Format("{0:n}", contphilhealth);
            label45.Text = String.Format("{0:n}", totaldeduct);
            label66.Text = String.Format("{0:n}", sss);
            label62.Text = String.Format("{0:n}", philhealth);
            label59.Text = String.Format("{0:n}", canteen);
            label53.Text = String.Format("{0:n}", cashadv);
            label49.Text = String.Format("{0:n}", loans);
            label70.Text = String.Format("{0:n}", others);
            // Earnings
            label41.Text = String.Format("{0:n}", totalearn);
            label37.Text = Convert.ToString(latemins) + " min(s)";
            label38.Text = String.Format("{0:n}", latexrate);
            label33.Text = Convert.ToString(absentdays) + " day(s)";
            label34.Text = String.Format("{0:n}", absentxrate);
            label26.Text = Convert.ToString(undertimehours) + " hr(s)";
            label27.Text = String.Format("{0:n}", underxrate);
            label17.Text = Convert.ToString(overtimehours) + " hr(s)";
            label18.Text = String.Format("{0:n}", overxrate);
            label15.Text = Convert.ToString(hourswork) + " hr(s)";
            label13.Text = String.Format("{0:n}", ratexbasic);
            label76.Text = mainpage.empname;
            label5.Text = mainpage.empnum;
            label1.Text = mainpage.empname;
            label7.Text = DateTime.Now.ToString("dddd, MMM dd yyyy");

            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label31_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label69_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Bitmap bitmap = new Bitmap(this.Width, this.Height);
            DrawToBitmap(bitmap, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
            var newimage = new Bitmap(bitmap);
            saved savedform = new saved();

            savedform.bitmapsave = newimage; 
            savedform.ShowDialog();
        }

        private void label79_Click(object sender, EventArgs e)
        {

        }
    }
}
