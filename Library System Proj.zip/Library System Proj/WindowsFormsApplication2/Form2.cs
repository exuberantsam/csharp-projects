﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            var formLogout = new Form3();
            formLogout.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var textSearch = textBox1.Text;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.Show();
            tabControl1.SelectTab(tabSettings);
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#11325B");
            label2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            radioButton1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            radioButton2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            radioButton5.ForeColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            radioButton7.ForeColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
            radioButton8.ForeColor = System.Drawing.ColorTranslator.FromHtml("#FFFFFF");
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton7.Checked == true)
            {
                this.BackColor = System.Drawing.ColorTranslator.FromHtml("#272822");
                label2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#A6E22E");
                radioButton1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#A6E22E");
                radioButton2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#A6E22E");
                radioButton5.ForeColor = System.Drawing.ColorTranslator.FromHtml("#A6E22E");
                radioButton7.ForeColor = System.Drawing.ColorTranslator.FromHtml("#A6E22E");
                radioButton8.ForeColor = System.Drawing.ColorTranslator.FromHtml("#A6E232");
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton8.Checked == true)
            {
                this.BackColor = Color.FloralWhite;
                label2.ForeColor = Color.Black;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                this.BackColor = Color.Black;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            var formLogout = new Form3();
            formLogout.Show();

        }

        private void button12_Click(object sender, EventArgs e)
        {


        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_VisibleChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.Show();
            tabControl1.SelectTab(tabGenre);
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.Show();
            tabControl1.SelectTab(tabAddBooks);
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        //FUNCTIONS TO PREVENT DUPLICATIONS IN LISTBOX
        
        public void showError()
        {
            MessageBox.Show("Please Input a Valid Book Title and Genre", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        public void duplicateError()
        {
            MessageBox.Show("This Book is Already Existing!", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void button8_Click_1(object sender, EventArgs e)
        {

            string titleBook = bookTitle.Text;
            string genreBook = bookGenre.Text;

            

            //ACTION GENRE
            if (titleBook != "" && genreBook == "Action" && (!actionGenre.Items.Contains(bookTitle.Text)))
            {
                actionGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabAction);
            }

            //HISTORY GENRE
            else if (titleBook != "" && genreBook == "History" && (!historyGenre.Items.Contains(bookTitle.Text)))
            {
                historyGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabHistory);
            }

            //ROMANCE GENRE
            else if (titleBook != "" && genreBook == "Romance" && (!romanceGenre.Items.Contains(bookTitle.Text)))
            {
                romanceGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabRomance);
            }


            //POLITICS GENRE
            else if (titleBook != "" && genreBook == "Politics" && (!politicsGenre.Items.Contains(bookTitle.Text)))
            {
                politicsGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabPolitics);
            }

            //DRAMA GENRE
            else if (titleBook != "" && genreBook == "Drama" && (!dramaGenre.Items.Contains(bookTitle.Text)))
            {
                dramaGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabDrama);
            }

            //SCIFI GENRE
            else if (titleBook != "" && genreBook == "Sci-Fi" && (!scifiGenre.Items.Contains(bookTitle.Text)))
            {
                scifiGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabScifi);
            }


            //DOCUMENTARY GENRE
            else if (titleBook != "" && genreBook == "Documentary" && (!documentaryGenre.Items.Contains(bookTitle.Text)))
            {
                documentaryGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabDocumentary);
            }

            //MYSTERY GENRE
            else if (titleBook != "" && genreBook == "Mystery" && (!mysteryGenre.Items.Contains(bookTitle.Text)))
            {
                mysteryGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabMystery);
            }

            //EDUCATIONAL GENRE
            else if (titleBook != "" && genreBook == "Educational" && (!educationalGenre.Items.Contains(bookTitle.Text)))
            {
                educationalGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabEducational);
            }

            //FANTASY GENRE
            else if (titleBook != "" && genreBook == "Fantasy" && (!fantasyGenre.Items.Contains(bookTitle.Text)))
            {
                fantasyGenre.Items.Add(this.bookTitle.Text);
                MessageBox.Show("Book Added Successfully!");
                tabControl1.SelectTab(tabFantasy);
            }

            else if (fantasyGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (politicsGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (mysteryGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (documentaryGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (dramaGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (actionGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (scifiGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (historyGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (romanceGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }
            else if (educationalGenre.Items.Contains(bookTitle.Text))
            {
                duplicateError();
            }

            else
            {
                showError();
            }

        }



        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAction);
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabHistory);
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPolitics);
        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabRomance);
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabDrama);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabScifi);
        }

        private void pictureBox8_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void bookAuthor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void bookTitle_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_2(object sender, EventArgs e)
        {

        }

        private void tabPage7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click_1(object sender, EventArgs e)
        {
            bookTitle.Clear();
            bookTitle.Focus();
            bookGenre.SelectedItem = null;
        }

        private void button23_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            tabControl1.Hide();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            tabControl1.Hide();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            tabControl1.Hide();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            tabControl1.Hide();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabEducational);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabDocumentary);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabMystery);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabFantasy);
        }

        private void button29_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button30_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button32_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }

        private void button31_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabAddBooks);
        }
    }
}
